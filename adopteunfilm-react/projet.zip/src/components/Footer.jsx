import React from 'react';

const Footer = () => {
    return (
        <footer>
            <p>&copy; 2025 AdopteUnFilm</p>
        </footer>
    );
};

export default Footer;